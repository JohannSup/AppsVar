package mx.edu.utez.appsvar4a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import mx.edu.utez.appsvar4a.databinding.ActivityMain2Binding
import mx.edu.utez.appsvar4a.databinding.ActivityMainBinding

class MainActivity2 : AppCompatActivity() {
    lateinit var binding: ActivityMain2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)


        var memoria = intent.getStringExtra("memoria")

        binding.btnSig2.setOnClickListener {
            val seleccion = binding.rgMemoria.checkedRadioButtonId
            var procesador = ""
            when(seleccion){
                R.id.rb1opc -> {procesador = "i3"}
                R.id.rb2opc -> {procesador = "i5"}
                R.id.rb3opc -> {procesador = "i7"}
                else -> {procesador = "Sin seleccion Procesador"}
            }


            val intent = Intent(this@MainActivity2,MainActivity3::class.java)
            intent.putExtra("memoria",memoria)
            intent.putExtra("procesador",procesador)

            startActivity(intent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        ///Inflate = es leer un archivo XML (diseño) y crea una instancia de el
        ///  con sus controles(inflar)
        menuInflater.inflate(R.menu.menu_main,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.mnuAbrir -> {
                Toast.makeText(this@MainActivity2, "Click en abrir",
                    Toast.LENGTH_SHORT).show()
            }
            R.id.mnuSalir -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}