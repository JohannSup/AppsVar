package mx.edu.utez.appsvar4a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import mx.edu.utez.appsvar4a.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSig1.setOnClickListener {
            val seleccion = binding.rgMemoria.checkedRadioButtonId
            var memoria = ""
            when(seleccion){
                R.id.rb4GB -> {memoria = "4GB"}
                R.id.rb8GB -> {memoria = "8GB"}
                R.id.rb16GB -> {memoria = "16GB"}
                else -> {memoria = "Sin seleccion en Memoria"}
            }
            val intent = Intent(this@MainActivity,MainActivity2::class.java)
            intent.putExtra("memoria",memoria)
            startActivity(intent)
        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        ///Inflate = es leer un archivo XML (diseño) y crea una instancia de el
        ///  con sus controles(inflar)
        menuInflater.inflate(R.menu.menu_main,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.mnuAbrir -> {
                Toast.makeText(this@MainActivity, "Click en abrir",
                Toast.LENGTH_SHORT).show()
            }
            R.id.mnuSalir -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}